# Employee Management System

Java + MySQL + JDBC project.

Features:
- Login System
- Add Employee
- Update Employee
- Delete Employee
- Search Employee
- JDBC Connectivity
- OOP Concepts
- Exception Handling

Default Login:
admin / admin123
