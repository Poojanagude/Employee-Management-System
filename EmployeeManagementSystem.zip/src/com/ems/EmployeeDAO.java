
package com.ems;
import java.sql.*;
public class EmployeeDAO {
    public void addEmployee(Employee e) throws Exception{
        String sql="INSERT INTO employees(id,name,department,salary) VALUES(?,?,?,?)";
        try(Connection con=DBConnection.getConnection();
            PreparedStatement ps=con.prepareStatement(sql)){
            ps.setInt(1,e.getId());
            ps.setString(2,e.getName());
            ps.setString(3,e.getDepartment());
            ps.setDouble(4,e.getSalary());
            ps.executeUpdate();
        }
    }
}
