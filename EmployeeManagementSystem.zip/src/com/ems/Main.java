
package com.ems;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Username: ");
        String u=sc.nextLine();
        System.out.print("Password: ");
        String p=sc.nextLine();
        if(!Login.authenticate(u,p)){
            System.out.println("Invalid Login");
            return;
        }
        System.out.println("Login Successful");
        System.out.println("Features: Add, Update, Delete, Search Employee");
    }
}
