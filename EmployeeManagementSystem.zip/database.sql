
CREATE DATABASE ems;
USE ems;
CREATE TABLE employees(
id INT PRIMARY KEY,
name VARCHAR(100),
department VARCHAR(100),
salary DOUBLE
);
